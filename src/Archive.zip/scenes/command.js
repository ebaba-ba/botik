const launchScene = (ctx) => ctx.scene.enter("start");
const startCitiesScene = (ctx) => ctx.scene.enter("cities");
module.exports = { launchScene, startCitiesScene };
